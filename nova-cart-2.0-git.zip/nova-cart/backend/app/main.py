from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from uuid import uuid4
from app.core.rate_limit import limiter
from pathlib import Path
from app.api.routes import router
from app.db.session import engine, Base
from app.models import *

class SecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        request.state.request_id = request.headers.get("X-Request-ID") or uuid4().hex
        if request.url.path.startswith("/api/") and not limiter.allow((request.client.host if request.client else "unknown", request.url.path)):
            return JSONResponse(status_code=429,content={"success":False,"error":{"code":"RATE_LIMITED","message":"Too many requests"},"requestId":request.state.request_id})
        try:
            response=await call_next(request)
        except Exception:
            return JSONResponse(status_code=500,content={"success":False,"error":{"code":"INTERNAL_ERROR","message":"Unexpected server error"}})
        response.headers["X-Content-Type-Options"]="nosniff"
        response.headers["X-Request-ID"]=request.state.request_id
        response.headers["X-Frame-Options"]="DENY"
        response.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"]="default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self'"
        return response

app=FastAPI(title="Nova Cart API", version="2.0.0")
app.add_middleware(SecurityMiddleware)
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(router)

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

frontend=Path(__file__).resolve().parents[2]/"frontend"/"dist"
if frontend.exists():
    assets_dir = frontend/"assets"
    if assets_dir.exists():
        app.mount("/assets",StaticFiles(directory=assets_dir),name="assets")
    @app.get("/",include_in_schema=False)
    def index(): return FileResponse(frontend/"index.html")
    @app.get("/{path:path}",include_in_schema=False)
    def spa(path:str):
        target=frontend/path
        return FileResponse(target if target.is_file() else frontend/"index.html")
