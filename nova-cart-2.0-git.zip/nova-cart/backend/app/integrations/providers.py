from dataclasses import dataclass
from abc import ABC, abstractmethod
import uuid, math

class PaymentProvider(ABC):
    @abstractmethod
    def create_intent(self, amount_paise:int, order_code:str)->dict: ...
    @abstractmethod
    def verify(self, provider_ref:str)->bool: ...

class MockPaymentProvider(PaymentProvider):
    def create_intent(self, amount_paise, order_code):
        return {"provider":"MOCK","reference":f"mockpay_{uuid.uuid4().hex[:12]}","amount_paise":amount_paise,"status":"CONFIRMED"}
    def verify(self, provider_ref): return provider_ref.startswith("mockpay_")

class RoutingProvider:
    mode = "MOCK/DEVELOPMENT"
    def route(self, a:tuple[float,float], b:tuple[float,float])->dict:
        # Development-only straight-line estimate.
        km = math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2) * 111
        return {"distance_km": round(km,2), "eta_min": max(5, round(km*4)), "provider":self.mode}

class OCRProvider:
    mode="MOCK/DEVELOPMENT"
    def extract(self, storage_key:str)->dict:
        return {"status":"MOCK_REVIEW_REQUIRED","fields":{},"provider":self.mode}

class NotificationProvider:
    mode="MOCK/DEVELOPMENT"
    def send(self, destination:str, message:str)->dict:
        return {"accepted":True,"provider":self.mode,"destination":destination}

class StorageProvider:
    mode="LOCAL_PRIVATE/DEVELOPMENT"
    def validate_filename(self, name:str)->bool:
        return not any(x in name for x in ["..","/","\\"]) 
