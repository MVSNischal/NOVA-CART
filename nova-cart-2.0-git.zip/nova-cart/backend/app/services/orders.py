from sqlalchemy import select
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models.entities import Order, OrderItem, OrderEvent, Product
from uuid import uuid4

ALLOWED = {
    "CREATED": {"PAYMENT_PENDING","PAYMENT_CONFIRMED","CANCELLED"},
    "PAYMENT_PENDING": {"PAYMENT_CONFIRMED","FAILED","CANCELLED"},
    "PAYMENT_CONFIRMED": {"SHOP_SELECTION","CANCELLED"},
    "SHOP_SELECTION": {"SHOP_ACCEPTED","FAILED","CANCELLED"},
    "SHOP_ACCEPTED": {"PREPARING","CANCELLED"},
    "PREPARING": {"READY_FOR_PICKUP","CANCELLED"},
    "READY_FOR_PICKUP": {"DELIVERY_ASSIGNMENT"},
    "DELIVERY_ASSIGNMENT": {"DELIVERY_ASSIGNED","FAILED"},
    "DELIVERY_ASSIGNED": {"PICKED_UP","FAILED"},
    "PICKED_UP": {"OUT_FOR_DELIVERY","FAILED"},
    "OUT_FOR_DELIVERY": {"DELIVERED","FAILED"},
    "DELIVERED": set(), "CANCELLED": set(), "REFUNDED": set(), "FAILED": set()
}

def transition(db:Session, order:Order, actor_id:int, new_status:str):
    if new_status not in ALLOWED.get(order.status,set()):
        raise HTTPException(409, detail={"code":"INVALID_ORDER_TRANSITION","message":f"{order.status} → {new_status} is not permitted"})
    old=order.status; order.status=new_status
    db.add(OrderEvent(order_id=order.id,actor_id=actor_id,previous_status=old,new_status=new_status)); db.commit(); db.refresh(order)
    return order

def make_code(): return "NC-" + uuid4().hex[:10].upper()
