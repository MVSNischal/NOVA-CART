from datetime import datetime, timezone, timedelta
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import User, Session as DbSession, SessionSecurityEvent
from app.core.security import verify_password, new_session_token, token_hash
from app.core.config import get_settings


def authenticate(db: Session, phone: str, password: str):
    user = db.scalar(select(User).where(User.phone == phone, User.active == True))
    if not user or not user.password_hash or not verify_password(password, user.password_hash):
        return None
    token = new_session_token()
    db.add(DbSession(token_hash=token_hash(token), user_id=user.id, expires_at=datetime.now(timezone.utc)+timedelta(seconds=get_settings().session_ttl_seconds)))
    db.commit()
    return user, token


def current_user(db: Session, token: str|None):
    if not token: return None
    s = db.scalar(select(DbSession).where(DbSession.token_hash == token_hash(token)))
    if not s: return None
    expires = s.expires_at
    if expires.tzinfo is None: expires = expires.replace(tzinfo=timezone.utc)
    if expires < datetime.now(timezone.utc): return None
    return db.get(User, s.user_id)

def audit(db: Session, user_id:int|None, event_type:str, detail:str, ip:str):
    db.add(SessionSecurityEvent(actor_id=user_id,event_type=event_type,detail=detail,ip=ip)); db.commit()
