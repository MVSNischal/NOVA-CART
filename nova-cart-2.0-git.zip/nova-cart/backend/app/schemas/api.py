from pydantic import BaseModel, Field
from typing import Literal

class LoginIn(BaseModel):
    phone: str
    password: str

class UserOut(BaseModel):
    id: int; name: str; phone: str; role: str

class ProductOut(BaseModel):
    id: int; shop_id: int; name: str; category: str; description: str; price_paise: int; stock: int; prescription_required: bool; image_url: str | None

class CartAdd(BaseModel):
    product_id: int; quantity: int = Field(ge=1, le=50)

class CheckoutIn(BaseModel):
    address: str = Field(min_length=8, max_length=400)
    payment_method: Literal["COD", "MOCK_UPI"] = "COD"

class TransitionIn(BaseModel):
    status: str

class RoleUpdate(BaseModel):
    active: bool
