const json=async (res:Response)=>{const d=await res.json(); if(!res.ok) throw new Error(d?.detail?.message||d?.error?.message||d?.detail||'Request failed'); return d;};
export async function ensureCsrf(){await fetch('/api/csrf',{credentials:'include'});}
export async function api(path:string, options:RequestInit={}){const headers=new Headers(options.headers); if(options.method&&options.method!=='GET'){const c=document.cookie.split('; ').find(x=>x.startsWith('nova_csrf=')); if(c) headers.set('X-CSRF-Token',decodeURIComponent(c.split('=')[1]));} return json(await fetch(path,{...options,headers,credentials:'include'}));}
export const getCatalog=(q='',category='')=>api(`/api/catalog?q=${encodeURIComponent(q)}&category=${encodeURIComponent(category)}`);
export const getCart=()=>api('/api/cart');
export const getOrders=()=>api('/api/orders');
export const login=(phone:string,password:string)=>api('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phone,password})});
export const logout=()=>api('/api/auth/logout',{method:'POST'});
export const addCart=(product_id:number,quantity=1)=>api('/api/cart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({product_id,quantity})});
export const removeCart=(product_id:number)=>api(`/api/cart/${product_id}`,{method:'DELETE'});
export const checkout=(address:string,payment_method:'COD'|'MOCK_UPI')=>api('/api/checkout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({address,payment_method})});
export const transition=(id:number,status:string)=>api(`/api/orders/${id}/transition`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});
export const me=()=>api('/api/me');
export const adminOverview=()=>api('/api/admin/overview');
