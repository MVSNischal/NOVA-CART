export type User = {id:number;name:string;phone:string;role:string};
export type Product = {id:number;shop_id:number;name:string;category:string;description:string;price_paise:number;stock:number;prescription_required:boolean;image_url?:string;shop_name:string;shop_rating:number};
export type Cart = {items:{id:number;product_id:number;name:string;price_paise:number;quantity:number;stock:number;prescription_required:boolean}[];total_paise:number};
export type Order = {id:number;order_code:string;status:string;subtotal_paise:number;delivery_fee_paise:number;total_paise:number;payment_status:string;shop:string;address:string;created_at:string};
